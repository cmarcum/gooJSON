gooadd <-
function(address=list("street","city","state",...)){
    paste(address,collapse=", ")
}

